import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SearchFilter } from '../search-filter';

@Component({
  selector: 'app-search-filter-component',
  templateUrl: './search-filter-component.component.html',
  styleUrls: ['./search-filter-component.component.css']
})
export class SearchFilterComponentComponent implements OnInit {
//npm i bootstrap@5.2.2
  @Input()
   fieldName : string = "";
  @Input()
   operation : string ="" ;
  @Input()
   value1 : string = "";
  @Input()
   value2 : string = "";
   @Input()
   index : number = 0;

   @Output()
   searchFilterRemoved : EventEmitter<number> = new EventEmitter<number>();

  constructor( ) {
    }

  ngOnInit(): void {
  }

  onClickClose(){
    console.log("Clicked "+ this.fieldName + " "+this.operation+" "+this.value1+" "+this.value2);
    this.searchFilterRemoved.emit(this.index);
  }
}
