import { SearchFilter } from './search-filter';

describe('SearchFilter', () => {
  it('should create an instance', () => {
    //expect(new SearchFilter()).toBeTruthy();
  });
});
