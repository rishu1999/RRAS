import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private _http:HttpClient) { }

  public deleteEmployee(ids:Array<number>):Observable<string> {
    return this._http.delete<string>("http://localhost:8080/employees?ids="+ids.join("&ids="));
  }
}
