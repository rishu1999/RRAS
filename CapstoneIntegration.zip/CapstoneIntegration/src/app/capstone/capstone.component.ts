import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CapstoneService } from '../capstone.service';
import { CapstoneModule } from './capstone.module';

@Component({
  selector: 'app-capstone',
  templateUrl: './capstone.component.html',
  styleUrls: ['./capstone.component.css']
})
export class CapstoneComponent implements OnInit {

  Capstone = new CapstoneModule();

  msg = '';

  constructor(private _service:CapstoneService, private _router: Router) { }



  ngOnInit(): void {

  }

}