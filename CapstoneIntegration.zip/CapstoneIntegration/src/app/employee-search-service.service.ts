import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
// import { EmployeeEntity } from './employee-entity';
import { SearchFilter } from './search-filter';
import { TableData } from './tableData';

@Injectable({
  providedIn: 'root'
})
export class EmployeeSearchServiceService {

  private URL : string = "http://localhost:8080/search";
  constructor( private http : HttpClient) {

   }

   search(searchFilters : Array<SearchFilter>):Observable<Array<TableData>>{
     return this.http.post<Array<TableData>>(this.URL,searchFilters);
   }
}
