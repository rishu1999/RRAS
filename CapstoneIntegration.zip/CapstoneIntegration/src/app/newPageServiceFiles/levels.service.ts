import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Level } from './level';

@Injectable({
  providedIn: 'root'
})
export class LevelsService {

  URL: string = "http://localhost:8080/levels"

  constructor(private _http:HttpClient) {

   }

   viewAllLevels(): Observable< Array<Level>>{
     return this._http.get<Array<Level>>(this.URL);
   }
  }
