export class Experience {
    name : string = "";
    year : number = 0;
    month : number = 0;
    constructor(name : string,year:number,month:number){
        this.name = name;
        this.year = year;
        this.month = month;
    }
}
