export class Level {

    constructor(
        public id:number,
        public level:string,
        public description: string

         )
        {

    }
}
