import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Reportingmanager} from './reportingmanager';

@Injectable({
  providedIn: 'root'
})
export class reportingmanagersService {

  URL: string = "http://localhost:8080/managers"

  constructor(private _http:HttpClient) {

   }
   viewManagers(): Observable< Array<Reportingmanager>>{
     return this._http.get<Array<Reportingmanager>>(this.URL);
   }
  }