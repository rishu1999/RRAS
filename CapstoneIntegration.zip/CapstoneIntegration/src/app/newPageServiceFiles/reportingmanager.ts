export class Reportingmanager {
        constructor(
            public managerId:number,
            public managerName:string,
            public managerDescription: string

             )
            {

        }
    }


