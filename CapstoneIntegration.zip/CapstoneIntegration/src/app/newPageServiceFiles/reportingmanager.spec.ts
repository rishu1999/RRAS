import { Reportingmanager } from './reportingmanager';

describe('Reportingmanager', () => {
  it('should create an instance', () => {
    expect(new Reportingmanager()).toBeTruthy();
  });
});
