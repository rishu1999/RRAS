export class Role {


        constructor(
            public id:number,
            public rolename:string,
            public description: string
    
             )
            {
    
        }
    }
