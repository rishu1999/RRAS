import { TestBed } from '@angular/core/testing';

import { reportingmanagersService } from './reportingmanagers.service';

describe('ReportingmanagersService', () => {
  let service: reportingmanagersService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(reportingmanagersService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
