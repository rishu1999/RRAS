import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Role } from './role';

@Injectable({
  providedIn: 'root'
})
export class rolesService {

  URL: string = "http://localhost:8080/roles"

  constructor(private _http:HttpClient) {

   }

   viewRoles(): Observable< Array<Role>>{
     return this._http.get<Array<Role>>(this.URL);
   }
  }
