import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdvancedSearchComponent } from './advanced-search/advanced-search.component';

import { CapstoneComponent } from './capstone/capstone.component';
import { TableDataComponent } from './table-data/table-data.component';
import { RegistrationComponent } from './registration/registration.component';


const routes: Routes = [
{ path: '', redirectTo: 'gridPage', pathMatch: 'full' },
{path:"gridPage",component:AdvancedSearchComponent},
{path: 'data', component: TableDataComponent},
{path: 'registration', component: RegistrationComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
