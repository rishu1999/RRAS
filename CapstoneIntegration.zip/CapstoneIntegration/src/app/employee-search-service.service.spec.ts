import { TestBed } from '@angular/core/testing';

import { EmployeeSearchServiceService } from './employee-search-service.service';

describe('EmployeeSearchServiceService', () => {
  let service: EmployeeSearchServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeeSearchServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
