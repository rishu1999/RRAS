import { SelectionModel } from '@angular/cdk/collections';
import { Component, Input, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { DisplayService } from '../display.service';
import { TableData } from '../tableData';


@Component({
  selector: 'app-table-data',
  templateUrl: './table-data.component.html',
  styleUrls: ['./table-data.component.css']
})
export class TableDataComponent implements OnInit {
  TableData: TableData[] = [];
  displayedColumns: string[] = ['select','mphasisId','userName', 'role','deliveryManager', 'levelId','mphasisJoinedDate'];
 // dataSource = ELEMENT_DATA;
  public dataSource = new MatTableDataSource<TableData>();

  @Input()
  filteredData: TableData[] | null= [];

  constructor(private http:DisplayService) { }

  ngOnInit(): void {
    //this.getData();
    this.http.getSelectedIds = this.getSelectedIds;
  }
  selection = new SelectionModel<TableData>(true, []);

  getData(){
    if (this.filteredData == null){
      // this.http.getTableData()
      // .subscribe((res)=>{
      //   console.log(res);
      //   this.dataSource.data = res;
      // })
      this.dataSource.data = [];
    }
    else{
      this.dataSource.data = this.filteredData;
    }
    this.selection.clear();



    /*
    this.http.getTableData()
      .subscribe((res)=>{
        console.log(res);
        this.dataSource.data = res;
      })
    */
  }

  ngOnChanges() : void{
    this.getData();
  }


  getSelectedIds = () =>  {
    let ids : number[] = [];
    for (let item of this.selection.selected){
      ids.push(item.mphasisId);
    }
    return ids;
  }
}
