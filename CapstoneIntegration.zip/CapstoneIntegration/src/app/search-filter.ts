export class SearchFilter {
    constructor(
        public fieldName : string,
        public operation : string,
        public value1 : string,
        public value2 : string = ""
    ){

    }

    equals(searchFilter : SearchFilter): boolean{
        return (this.fieldName == searchFilter.fieldName)&&
        (this.operation == searchFilter.operation)&&
        (this.value1 == searchFilter.value1)&&
        (this.value2 == searchFilter.value2)
    }

    sameCondition(searchFilter : SearchFilter):boolean{
        return (this.fieldName == searchFilter.fieldName)&&
        (this.operation == searchFilter.operation)
    }
}
