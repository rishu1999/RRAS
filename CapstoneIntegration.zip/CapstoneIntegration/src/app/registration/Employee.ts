export class Employee {
  userName : string;
  mphasisId : string ;
  mphasisMailId : string ;
  mobileNumber : string ;
  deliveryManager: string;
  role:string;
  javaExperienceYear:string;
	javaExperienceMonth:string;
	springExperienceYear:string;
	springExperienceMonth:string;
	jpaExperienceYear:string;
	jpaExperienceMonth:string;
  seleniumExperienceYear:string;
  seleniumExperienceMonth:string;
  manualTestingExperienceYear:string;
  manualTestingExperienceMonth:string;
  databaseExperienceYear:string;
  databaseExperienceMonth:string;
  applicationSupportingExperienceYear:string;
  applicationSupportingExperienceMonth:string;
  cloudAppExperienceYear:string;
  cloudAppExperienceMonth:string;
  PCFExperienceYear:string;
  PCFExperienceMonth:string;
  resourceBlocked:string;
  gender:string;
  overallExperienceYear:string;
  overallExperienceMonth:string;
  mphasisJoinedDate:string;
  todayDate:string;
    constructor(username : string,mphid : string,mphEmail : string,mobile : string, deliveryManager:string,role:string,resourceBlocked:string,javaExperienceYear:string,javaExperienceMonth:string,springExperienceYear:string,springExperienceMonth:string,jpaExperienceYear:string,jpaExperienceMonth:string,gender:string,overallExperienceYear:string,overallExperienceMonth:string,mphasisJoinedDate:string,seleniumExperienceYear:string,seleniumExperienceMonth:string,manualTestingExperienceYear:string,manualTestingExperienceMonth:string,databaseExperienceYear:string,databaseExperienceMonth:string,applicationSupportingExperienceYear:string,applicationSupportingExperienceMonth:string,cloudAppExperienceYear:string,cloudAppExperienceMonth:string,PCFExperienceYear:string,PCFExperienceMonth:string){
    // constructor(username : string,mphid : string,mphEmail : string,mobile : string, deliveryManager:string,role:string,resourceBlocked:string,javaExperienceYear:number,javaExperienceMonth:number,springExperienceYear:number,springExperienceMonth:number,jpaExperienceYear:number,jpaExperienceMonth:number,seleniumExperienceYear:number,seleniumExperienceMonth:number){
        let date = new Date();
        this.todayDate = date.getFullYear()+"-"+date.getMonth()+"-"+date.getDate();

        this.userName = username;
        this.mphasisId = mphid;
        this.mphasisMailId = mphEmail;
        this.mobileNumber = mobile;
        this.deliveryManager= deliveryManager;
        this.role= role;
        this.resourceBlocked="Yes";
        this.javaExperienceYear=javaExperienceYear;
        this.javaExperienceMonth=javaExperienceMonth;
        this.springExperienceYear=springExperienceYear;
        this.springExperienceMonth=springExperienceMonth;
        this.jpaExperienceYear=jpaExperienceYear;
        this.jpaExperienceMonth=jpaExperienceMonth;
        this.seleniumExperienceYear=seleniumExperienceYear;
        this.seleniumExperienceMonth=  seleniumExperienceMonth;
        this.manualTestingExperienceYear=  manualTestingExperienceYear;
        this.manualTestingExperienceMonth=  manualTestingExperienceMonth;
        this.databaseExperienceYear=  databaseExperienceYear;
        this.databaseExperienceMonth=  databaseExperienceMonth;
        this.applicationSupportingExperienceYear=  applicationSupportingExperienceYear;
        this.applicationSupportingExperienceMonth=  applicationSupportingExperienceMonth;
        this.cloudAppExperienceYear=  cloudAppExperienceYear;
        this.cloudAppExperienceMonth=  cloudAppExperienceMonth;
        this.PCFExperienceYear=  PCFExperienceYear;
        this.PCFExperienceMonth=  PCFExperienceMonth;
        this.gender= gender;
        this.overallExperienceYear=overallExperienceYear;
        this.overallExperienceMonth=overallExperienceMonth;
        this.mphasisJoinedDate=this.todayDate;
    }
}
