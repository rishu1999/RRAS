import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { NewPageExpClass } from '../newpage/new-page-exp-class';
import { Experience } from '../newPageServiceFiles/experience';
import { UserRegistrationService } from '../user-registration-service';
import { Employee } from './Employee';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  employee: Employee = new Employee("","","","","","","","","","","","","","","","","","","","","","","","","","","","","");
  message: any;
  fileUploadMessage:any;
  userFile: any = File;
  user: NewPageExpClass = new NewPageExpClass("","","","","","","","","","","","","","","","","","","","","");
  validForm:Boolean = false;
  validval:number=0;
  resourceBlocked:string;
  registerForm!: any;
  title = 'formvalidation'
  submitted=false;
  formData:FormData;
  constructor(private formBuilder:FormBuilder,private service:UserRegistrationService, private _router : Router) {
    this.resourceBlocked="Yes";
    this.formData = new FormData();
  }
  todayDate:any="";
  // constructor() { }
  // {"id":2,"userName":"username","mphasisId":null,"mphasisMailId":null,"mobileNumber":null,"levelId":0,"deliveryManager":null,"role":null,"resourceBlocked":null,"javaExperienceYear":0,"javaExperienceMonth":0,"springExperienceYear":0,"springExperienceMonth":0,"jpaExperienceYear":0,"jpaExperienceMonth":0,"seleniumExperienceYear":0,"seleniumExperienceMonth":0,"manualTestingExperienceYear":0,"manualTestingExperienceMonth":0,"databaseExperienceYear":0,"databaseExperienceMonth":0,"applicationSupportingExperienceYear":0,"applicationSupportingExperienceMonth":0,"cloudAppExperienceYear":0,"cloudAppExperienceMonth":0,"overallExperienceYear":0,"overallExperienceMonth":0,"gender":null,"updatedResume":null,"mphasisJoinedDate":null,"pcfexperienceMonth":0,"pcfexperienceYear":0}
  ngOnInit(): void {
    //validation
    this.registerForm = this.formBuilder.group({
      userName:['',Validators.required],
      userEmail : ["", [Validators.required, Validators.email]],
      usermphasisId : ["", [Validators.required,Validators.pattern("^[0-9]*$"), Validators.maxLength(7),Validators.maxLength(10)]],
      userPhone :["",[Validators.required,Validators.pattern("^[0-9]*$"), Validators.maxLength(10), Validators.minLength(10)]],
      gender:["",[Validators.required]],
      overAllExpYear:["",[Validators.required]],
      overAllExpMonth:["",[Validators.required]],
      fileUpload:["",[Validators.required]]

    });

    this.disableFutureDates();

  }

  public registerNow(){
    this.submitted=true;
    console.log(this.submitted);
    console.log(this.user);
    this.employee = {...this.employee,...this.user};
    console.log(this.employee);
    // this.getFile();
        let response = this.service.doRegistration(this.employee);
        response.subscribe((data)=>this.message=data);
      // }
      let response2 = this.service.fileUploadService(this.formData);
      response2.subscribe((data)=>this.fileUploadMessage=data);

    }

    getObject(event:any){
      console.log(event);
      this.user= event;
    }

    cancel(){
        console.log("this is running");
        this._router.navigate(['gridPage'])

    }

    getFile(event:any){
      // console.log(event.target.files[0]);
      this.userFile = event.target.files[0];
      // const formData = new FormData();
      // console.log(this.employee.mphasisId);
      if(this.userFile.size/1024 >200){
        alert("file size is greater than 2mb");
        event.target.value = "";
        this.registerForm.status = "INVALID";
        // console.log(this.registerForm);
      }
      else{
        this.formData.append('mphasisId',this.employee.mphasisId);
        this.formData.append('file',this.userFile);
        console.log(this.userFile.size);
      }

    }

    confirmAllDetails(employee:Employee){
      if(employee.userName!="" && employee.mphasisId!=""&& employee.mphasisMailId!=""&& employee.mobileNumber!=""){
        this.validForm=true;
      }
    }

    disableFutureDates(){
      let date = new Date();
      this.todayDate = date.getFullYear()+"-"+date.getMonth()+"-"+date.getDate();

    }

    submitNow(){
        console.log(this.registerForm.validForm);


      const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
          confirmButton: 'btn btn-success mx-3',
          cancelButton: 'btn btn-danger'
        },
        buttonsStyling: false
      })

      swalWithBootstrapButtons.fire({
        title: 'Are you sure?',
        text: "You want to save this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, save it!',
        cancelButtonText: 'No, cancel!',
        reverseButtons: true
      }).then((result) => {
        if (result.isConfirmed) {
          this.registerNow();
          swalWithBootstrapButtons.fire(
            'Saved!',
            'Employee details saved.',
            'success'
          )
          this._router.navigate(['gridPage']);
        } else if (
          /* Read more about handling dismissals below */
          result.dismiss === Swal.DismissReason.cancel
        ) {
        }
      })
    }
}
