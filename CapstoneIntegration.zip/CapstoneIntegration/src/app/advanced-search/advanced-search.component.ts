import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DisplayService } from '../display.service';
import { EmployeeSearchServiceService } from '../employee-search-service.service';
import { EmployeeService } from '../employee.service';
import { SearchFilter } from '../search-filter';
import { TableData } from '../tableData';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-advanced-search',
  templateUrl: './advanced-search.component.html',
  styleUrls: ['./advanced-search.component.css']
})
export class AdvancedSearchComponent implements OnInit {

  searchFilters : Array<SearchFilter> = [];

  filteredData: TableData[] | null = null;

  constructor(private _router:Router,private searchService : EmployeeSearchServiceService,private displayService : DisplayService,private employeeService : EmployeeService) { }

  ngOnInit(): void {
    this.searchService.search([]).subscribe({
          next:response => {
            console.log("Search response ="+JSON.stringify(response));
            this.filteredData = response;
          }
        });
  }


newEmployee(){
this._router.navigate(['registration'])
}
deleteEmployee(){
  //this._router.navigate(['Capstone']);
  if (this.displayService.getSelectedIds){
    let selectedIds : number[] = this.displayService.getSelectedIds();
    console.log("Selected ids  "+JSON.stringify(selectedIds));
    this.employeeService.deleteEmployee(selectedIds).subscribe(
      {
        next:response => {
          alert(response);
          this.search();
        },
        error : e => {
          console.log("Error :"+JSON.stringify(e));
          this.search();
        }
      }
    );
  }

  }

  searchFiltersApplied(searchFilters : Array<SearchFilter>){
    // if (searchFilters == null || searchFilters.length == 0){
    //   this.filteredData = null;
    // }
    // else{
    //   this.searchService.search(searchFilters).subscribe({
    //     next:response => {
    //       console.log("Search response =="+JSON.stringify(response));
    //       this.filteredData = response;
    //     }
    //   });
    // }

    this.searchFilters = searchFilters;
    this.search();
  }

  search(){
    this.searchService.search(this.searchFilters).subscribe({
      next:response => {
        console.log("Search response =="+JSON.stringify(response));
        this.filteredData = response;
      }
    });
  }

  openSweetAlert(){
      const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
          confirmButton: 'btn btn-success mx-3',
          cancelButton: 'btn btn-danger'
        },
        buttonsStyling: false
      })

      swalWithBootstrapButtons.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!',
        reverseButtons: true
      }).then((result) => {
        if (result.isConfirmed) {
          this.deleteEmployee();
          swalWithBootstrapButtons.fire(
            'Deleted!',
            'Your file has been deleted.',
            'success'
          )
        } else if (
          /* Read more about handling dismissals below */
          result.dismiss === Swal.DismissReason.cancel
        ) {
          swalWithBootstrapButtons.fire(
            'Cancelled',
            'Your imaginary file is safe :)',
            'error'
          )
        }
      })

  }
}
