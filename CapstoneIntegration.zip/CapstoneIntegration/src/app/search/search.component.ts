import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { NgForm } from '@angular/forms';
import { EmployeeSearchServiceService } from '../employee-search-service.service';
import { SearchFilter } from '../search-filter';
import { TableData } from '../tableData';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  fieldName : string ="";
  operation : string = "";
  value : string ="";
  filterWithSearch : boolean = false;
  searchFilters : Array<SearchFilter> = [];
  filteredData: TableData[] = [];

  @Output()
   searchFiltersApplied : EventEmitter<Array<SearchFilter>> = new EventEmitter<Array<SearchFilter>>();

  constructor() { }

  ngOnInit(): void {
  }

  onSubmit(ngForm : NgForm){
    console.log("fieldName = "+this.fieldName+"operation = "+this.operation+" value ="+this.value+" filterwithsearch = "+this.filterWithSearch)
    this.setFilter();
    
    if (this.filterWithSearch){
      this.searchFiltersApplied.emit(this.searchFilters);

    }
    else{
      this.searchFiltersApplied.emit([]);
    }

  }

  setFilter(){
    this.searchFilters.push(new SearchFilter(this.fieldName,this.operation,this.value));

  }

  searchFilterRemoved(removed : boolean){
    if (removed){
      this.searchFiltersApplied.emit(this.searchFilters);
    }
  }

  

}
