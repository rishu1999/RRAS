import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CapstoneComponent } from './capstone/capstone.component';
import { AdvancedSearchComponent } from './advanced-search/advanced-search.component';
import { RouterModule } from '@angular/router';
import { SearchComponent } from './search/search.component';
import { SearchFilterComponentComponent } from './search-filter-component/search-filter-component.component';
import { SearchFiltersListComponent } from './search-filters-list/search-filters-list.component';
import { MaterialModule } from './material-module/material-module.module';
//import { AdvancedSearchComponent } from './advanced-search/advanced-search.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableDataComponent } from './table-data/table-data.component';
import { RegistrationComponent } from './registration/registration.component';
import { NewpageComponent } from './newpage/newpage.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
@NgModule({
  declarations: [
    AppComponent,
    CapstoneComponent,
    AdvancedSearchComponent,
    SearchComponent,
    SearchFilterComponentComponent,
    SearchFiltersListComponent,
    TableDataComponent,
    RegistrationComponent,
    NewpageComponent,
    SearchComponent,
    AdvancedSearchComponent
  ],
  imports: [
    HttpClientModule,
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,





  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
