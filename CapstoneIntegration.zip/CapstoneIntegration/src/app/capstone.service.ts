import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CapstoneModule } from './capstone/capstone.module';

@Injectable({
  providedIn: 'root'
})
export class CapstoneService {

  constructor(private http:HttpClient) { }

public registerCapstoneRemote(Capstone:CapstoneModule):Observable<any> {

  return this.http.post<any>("http://localhost:8084/api/v1/Capstone", Capstone)

  }
}
