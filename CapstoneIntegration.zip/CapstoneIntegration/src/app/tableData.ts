// export interface TableData{
//     id:number;
//     name:string;
//     role:string;

// }
export interface TableData{
    mphasisId:number;
    userName:string;
    role:string;
    deliveryManager:string;
    levelId:number;
    mphasisJoinedDate:string

}