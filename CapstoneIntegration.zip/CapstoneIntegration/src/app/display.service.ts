import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { TableData } from './tableData';

@Injectable({
  providedIn: 'root'
})
export class DisplayService {

  getSelectedIds : Function | null = null;
  constructor(private http: HttpClient) {
  }

  // getTableData(): Observable<TableData[]>{
  //   return this.http.get<TableData[]>("http://localhost:8080/employees");
  // }
}
