import { NewPageExpClass } from './new-page-exp-class';

describe('NewPageExpClass', () => {
  it('should create an instance', () => {
    expect(new NewPageExpClass()).toBeTruthy();
  });
});
