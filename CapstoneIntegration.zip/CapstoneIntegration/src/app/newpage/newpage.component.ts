import { ThisReceiver } from '@angular/compiler';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Experience } from '../newPageServiceFiles/experience';
import { Level } from '../newPageServiceFiles/level';
import { LevelsService } from '../newPageServiceFiles/levels.service';
import { Reportingmanager } from '../newPageServiceFiles/reportingmanager';
import { reportingmanagersService } from '../newPageServiceFiles/reportingmanagers.service';
import { Role } from '../newPageServiceFiles/role';
import { rolesService } from '../newPageServiceFiles/roles.service';
import { NewPageExpClass } from './new-page-exp-class';
// import { Level } from 'src/newPageServiceFiles/level';
// import { LevelsService } from 'src/newPageServiceFiles/levels.service';
// import { Reportingmanager } from 'src/newPageServiceFiles/reportingmanager';
// import { reportingmanagersService } from 'src/newPageServiceFiles/reportingmanagers.service';
// import { Role } from 'src/newPageServiceFiles/role';
// import { rolesService } from 'src/newPageServiceFiles/roles.service';
// import { Experience } from '../experience';

@Component({
  selector: 'app-newpage',
  templateUrl: './newpage.component.html',
  styleUrls: ['./newpage.component.css']
})
export class NewpageComponent implements OnInit {
  @Output() newItemEvent = new EventEmitter<NewPageExpClass>();
  level:any;
  // deliveryManager:string;
  deliveryManager:string;
  role:any;
  currRole:any;
  experiences : Experience[];
  MIN_YEAR : number = 0;
  MAX_YEAR : number = 30;
  years : number[];
  months:number[];
  reportingmanagers:Reportingmanager[]=[];
  levels : Level[] = [];
  roles: Role [] =[];
  name:string;
  user: NewPageExpClass = new NewPageExpClass("","","","","","","","","","","","","","","","","","","","","");
  constructor(private levelsService:LevelsService,private reportingmanagerservice:reportingmanagersService,private roleService:rolesService) {
    this.level="1";
    this.deliveryManager="1";
    this.experiences = [];
    this.years = [];
    this.months=[];
    this.name= "";
    this.role=1;
    this.currRole="developer";
    for (let i = 0; i <= (this.MAX_YEAR - this.MIN_YEAR);i++){
      this.years.push(this.MIN_YEAR + i);
    }
    for (let i = 0; i <=12;i++){
      this.months.push(i);
    }

    this.levelsService.viewAllLevels().subscribe({
      next : response =>{
        console.log("Levels ="+JSON.stringify(response));
        this.levels = response;
      }
    })


    this.reportingmanagerservice.viewManagers().subscribe({
      next : response =>{
        console.log("managers ="+JSON.stringify(response));
        this.reportingmanagers = response;
      }
    })

    this.roleService.viewRoles().subscribe({
      next : response =>{
        // console.log("roles ="+JSON.stringify(response));
        this.roles = response;
      }
    })
  }

  ngOnInit(): void {
    this.onchangeRole();
  }

  onchangeRole(){
    this.user.role = this.role;
    this.user.levelId = this.level;
    this.user.deliveryManager = this.deliveryManager;
    this.newItemEvent.emit(this.user);
    // this.deliveryManager = this.reportingmanagers[0].managerName;
    console.log(this.user);
    if(this.roles.length!==0){
      this.currRole = this.roles[this.role-1].rolename;
    }

    if (this.currRole == "developer"){
      console.log("this is running");
      this.experiences= [new Experience("Java",0,0),new Experience("Spring",0,0),new Experience("JPA",0,0)]
      console.log(this.experiences[0]);
    }
    else if (this.currRole == "tester"){
      this.experiences= [new Experience("Selenium",0,0),new Experience("Manual Testing",0,0),new Experience("Database",0,0)]

    }
    else if (this.currRole == "supporter"){
      this.experiences= [new Experience("Supporting",0,0),new Experience("CloudApp",0,0),new Experience("PCF",0,0)]

    }
  }

  onChangeLevel(event:any){
    let level= event.target.value;
    this.user.levelId = level;
    console.log(this.level);
  }
  onChangeManager(event:any){
    this.deliveryManager= event?.target.value;
    console.log(this.deliveryManager);
    this.user.deliveryManager=this.deliveryManager;
    console.log(this.deliveryManager);
  }

  onChangeExp(event:any){
    console.log(event.target.id);
    let currRole = this.roles[this.role-1].rolename;
    console.log(currRole);
    if(currRole=="developer"){
      if(event.target.name==="Java" && event.target.id==="year"){
        this.user.javaExperienceYear = event.target.value;
      }
      else if(event.target.name==="Java" && event.target.id==="month"){
        this.user.javaExperienceMonth=event.target.value;
      }
      else if(event.target.name==="Spring" && event.target.id==="year"){
        this.user.springExperienceYear = event.target.value;
      }
      else if(event.target.name==="Spring" && event.target.id==="month"){
        this.user.springExperienceMonth=event.target.value;
      }
      else if(event.target.name==="JPA" && event.target.id==="year"){
        this.user.jpaExperienceYear = event.target.value;
      }
      else if(event.target.name==="JPA" && event.target.id==="month"){
        this.user.jpaExperienceMonth=event.target.value;
      }
    }
    if(currRole=="tester"){
      if(event.target.name==="Selenium" && event.target.id==="year"){
        this.user.seleniumExperienceYear = event.target.value;
      }
      else if(event.target.name==="Selenium" && event.target.id==="month"){
        this.user.seleniumExperienceMonth=event.target.value;
      }
      else if(event.target.name==="Manual Testing" && event.target.id==="year"){
        this.user.manualTestingExperienceYear = event.target.value;
      }
      else if(event.target.name==="Manual Testing" && event.target.id==="month"){
        this.user.manualTestingExperienceMonth=event.target.value;
      }
      else if(event.target.name==="Database" && event.target.id==="year"){
        this.user.databaseExperienceYear = event.target.value;
      }
      else if(event.target.name==="Database" && event.target.id==="month"){
        this.user.databaseExperienceMonth=event.target.value;
      }
    }
    if(currRole=="supporter"){
      if(event.target.name==="Supporting" && event.target.id==="year"){
        this.user.applicationSupportingExperienceYear = event.target.value;
      }
      else if(event.target.name==="Supporting" && event.target.id==="month"){
        this.user.applicationSupportingExperienceMonth=event.target.value;
      }
      else if(event.target.name==="CloudApp" && event.target.id==="year"){
        this.user.cloudAppExperienceYear = event.target.value;
      }
      else if(event.target.name==="CloudApp" && event.target.id==="month"){
        this.user.cloudAppExperienceMonth=event.target.value;
      }
      else if(event.target.name==="PCF" && event.target.id==="year"){
        this.user.PCFExperienceYear = event.target.value;
      }
      else if(event.target.name==="PCF" && event.target.id==="month"){
        this.user.PCFExperienceMonth=event.target.value;
      }
    }

    console.log(this.user);
  }
}
