export class NewPageExpClass {

  deliveryManager: string;
  role:string;
  levelId:string;
  javaExperienceYear:string;
	javaExperienceMonth:string;
	springExperienceYear:string;
	springExperienceMonth:string;
	jpaExperienceYear:string;
	jpaExperienceMonth:string;
  seleniumExperienceYear:string;
  seleniumExperienceMonth:string;
  manualTestingExperienceYear:string;
  manualTestingExperienceMonth:string;
  databaseExperienceYear:string;
  databaseExperienceMonth:string;
  applicationSupportingExperienceYear:string;
  applicationSupportingExperienceMonth:string;
  cloudAppExperienceYear:string;
  cloudAppExperienceMonth:string;
  PCFExperienceYear:string;
  PCFExperienceMonth:string;

    // constructor(levelId:string,deliveryManager:string,role:string){
    constructor(levelId:string,deliveryManager:string,role:string,javaExperienceYear:string,javaExperienceMonth:string,springExperienceYear:string,springExperienceMonth:string,jpaExperienceYear:string,jpaExperienceMonth:string
      ,seleniumExperienceYear:string,seleniumExperienceMonth:string,manualTestingExperienceYear:string,manualTestingExperienceMonth:string,databaseExperienceYear:string,databaseExperienceMonth:string,applicationSupportingExperienceYear:string,applicationSupportingExperienceMonth:string,cloudAppExperienceYear:string,cloudAppExperienceMonth:string,PCFExperienceYear:string,PCFExperienceMonth:string){
    // constructor(username : string,mphid : string,mphEmail : string,mobile : string, deliveryManager:string,role:string,resourceBlocked:string,javaExperienceYear:number,javaExperienceMonth:number,springExperienceYear:number,springExperienceMonth:number,jpaExperienceYear:number,jpaExperienceMonth:number,seleniumExperienceYear:number,seleniumExperienceMonth:number
    //   ){

        this.deliveryManager= deliveryManager;
        this.role= role;
        this.levelId = levelId;
        this.javaExperienceYear=javaExperienceYear;
        this.javaExperienceMonth=	javaExperienceMonth;
        this.springExperienceYear=	springExperienceYear;
        this.springExperienceMonth=	springExperienceMonth;
        this.jpaExperienceYear=	jpaExperienceYear;
        this.jpaExperienceMonth=	jpaExperienceMonth;
        this.seleniumExperienceYear=seleniumExperienceYear;
        this.seleniumExperienceMonth=  seleniumExperienceMonth;
        this.manualTestingExperienceYear=  manualTestingExperienceYear;
        this.manualTestingExperienceMonth=  manualTestingExperienceMonth;
        this.databaseExperienceYear=  databaseExperienceYear;
        this.databaseExperienceMonth=  databaseExperienceMonth;
        this.applicationSupportingExperienceYear=  applicationSupportingExperienceYear;
        this.applicationSupportingExperienceMonth=  applicationSupportingExperienceMonth;
        this.cloudAppExperienceYear=  cloudAppExperienceYear;
        this.cloudAppExperienceMonth=  cloudAppExperienceMonth;
        this.PCFExperienceYear=  PCFExperienceYear;
        this.PCFExperienceMonth=  PCFExperienceMonth;

    }
}
