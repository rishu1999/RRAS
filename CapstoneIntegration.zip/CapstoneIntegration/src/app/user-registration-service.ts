import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './registration/Employee';

@Injectable({providedIn: 'root'})
export class UserRegistrationService {
    constructor(private http: HttpClient) {

    }
    /**
     * dorRegistration
     */
    public doRegistration(employee: Employee) {
        return this.http.post("http://localhost:8080/employee", employee);
    }
    public fileUploadService(uploadFileData: FormData) {
      console.log(uploadFileData.getAll('file'));
      console.log(uploadFileData.getAll('mphasisId'));
        return this.http.post("http://localhost:8080/upload", uploadFileData);
    }

}
