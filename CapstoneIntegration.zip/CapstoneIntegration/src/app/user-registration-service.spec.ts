import { UserRegistrationService } from './user-registration-service';

describe('UserRegistrationService', () => {
  it('should create an instance', () => {
    expect(new UserRegistrationService()).toBeTruthy();
  });
});
