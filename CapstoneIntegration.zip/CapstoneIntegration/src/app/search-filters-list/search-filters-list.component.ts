import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SearchFilter } from '../search-filter';

@Component({
  selector: 'app-search-filters-list',
  templateUrl: './search-filters-list.component.html',
  styleUrls: ['./search-filters-list.component.css']
})
export class SearchFiltersListComponent implements OnInit {

  @Input()
  searchFilters : Array<SearchFilter>;

  @Output()
   searchFilterRemoved : EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor() {

    this.searchFilters = [];
    
    
    
   }

  ngOnInit(): void {
  }

  onClickClose(index:number){
    console.log(this.searchFilters.splice(index,1));
    this.searchFilterRemoved.emit(true);
  }

  onClickClear(){
    this.searchFilters.splice(0,this.searchFilters.length);
    this.searchFilterRemoved.emit(true);
  }

}
