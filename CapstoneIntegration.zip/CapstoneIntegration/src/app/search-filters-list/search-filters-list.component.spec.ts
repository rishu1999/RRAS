import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFiltersListComponent } from './search-filters-list.component';

describe('SearchFiltersListComponent', () => {
  let component: SearchFiltersListComponent;
  let fixture: ComponentFixture<SearchFiltersListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchFiltersListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchFiltersListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
